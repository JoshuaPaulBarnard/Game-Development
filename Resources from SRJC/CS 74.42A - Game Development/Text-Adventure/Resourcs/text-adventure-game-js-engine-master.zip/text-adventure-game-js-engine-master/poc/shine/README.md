# shinecss
Welcome to Shine CSS!

This is an easy to use CSS framework created to boost your web design productivity. It provides a solid base of elements that 
can be used for any kind of design and it doesn't contain complex rules or elements, so it's quite easy to customize and to
add new personal improvements. 

Shine CSS is very lightweight, so it lets you create complex websites with minimal custom CSS code.

Feel free to fork and improve this project.
