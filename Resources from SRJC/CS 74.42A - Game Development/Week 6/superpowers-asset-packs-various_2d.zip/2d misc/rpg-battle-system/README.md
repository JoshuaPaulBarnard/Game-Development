# Superpowers RPG Battle System Asset Pack

Assets created by [Pixel-boy](https://twitter.com/2pblog1)
for [Superpowers](http://superpowers-html5.com/) supporters!

See https://github.com/sparklinlabs/superpowers-asset-packs
for license information and more assets!

![](preview.png)

![](mockup.png)
