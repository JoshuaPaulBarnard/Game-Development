# Superpowers Western FPS 2D Asset Pack

Assets created by [Pixel-boy](https://twitter.com/2pblog1)
for [Superpowers](http://superpowers-html5.com/) supporters!

See https://github.com/sparklinlabs/superpowers-asset-packs
for license information and more assets!

![](preview.png)

## Usage information

Tile size: 32x32
Characters and animals frame size: 63x66
